print("Bienvenido a la calculadora de Duarte")
print("Para salir escribe Salir")
print("Las opreraciones son suma, multi, div y resta")

while True:
    num1 = input("Ingrese un numero:")
    if num1.lower() == "salir":
        break
    num2 = input("Ingrese otro numero:")
    if num2.lower() == "salir":
        break
    operacion = input("Ingresa operacion:")
    if operacion.lower() == "salir":
        break
    num1 = int(num1)
    num2 = int(num2)
    if operacion == "suma":
        resultado = num1 + num2
    elif operacion == "resta":
        resultado = num1 - num2
    elif operacion == "multi":
        resultado = num1 * num2
    elif operacion == "div":
        resultado = num1 / num2
    else:
        print("Operacion no valida")
        continue
    print(f"El resultado de la {operacion} entre {num1} y {num2} es {resultado}")
print("Gracias por usar la calculadora de Duarte")